# Remittance AI: Phase 3 completed conditional dossier

**CONDITIONAL_HOLD. No operational model. No submission-ready original manuscript.** Continue from merged Phase 2; no broad model search was repeated.

- [Final scientific verdict](research_completion/phase3/assessment/FINAL_SCIENTIFIC_VERDICT.md)
- [Complete conditional research dossier](research_completion/phase3/manuscript/conditional_research_dossier.md)
- [Novelty decision and precise overlap limits](research_completion/phase3/literature/NOVELTY_DECISION.md)
- [Identity validity and blinded human-review protocol](research_completion/phase3/identity/MATCH_REVIEW_PROTOCOL.md)
- [Actual primary estimates](research_completion/phase3/identity/LINKAGE_SCENARIO_RESULTS.csv) and [paired width inference](research_completion/phase3/inference/PAIRED_MEASUREMENT_EFFECTS.csv)
- [Strict legacy failure and exact within-environment repeats](research_completion/phase3/reproducibility/RUN_COMPARISONS.csv)
- [Scientific audit](research_completion/phase3/assessment/SCIENTIFIC_AUDIT.md), [gate matrix](research_completion/phase3/assessment/PUBLICATION_GATE_MATRIX.csv) and [remaining external dependencies](research_completion/phase3/assessment/REMAINING_EXTERNAL_DEPENDENCIES.md)
- [Execution ledger](research_completion/phase3/EXECUTION_LEDGER.md), [supplementary replication methods](research_completion/phase3/manuscript/supplementary_methods.md), [figure legends](research_completion/phase3/manuscript/figure_legends.md), [claim ledger](research_completion/phase3/assessment/claim_evidence_ledger.csv)
- [Handoff and checksums](research_completion/phase3/deliverables/README.md)

The private 60-case identity form is on this Windows computer under ignored phase3/private_runtime/; it is deliberately absent from Git/ZIP. The public review template is schema-only. Raw data, provider rows, predictions, fitted objects and reading-copy PDFs are excluded. Future decision clocks/new temporal holdouts are needed for operational prediction, not automatically for the narrower finite-panel measurement paper. Human source/identity and contribution review remain necessary.
