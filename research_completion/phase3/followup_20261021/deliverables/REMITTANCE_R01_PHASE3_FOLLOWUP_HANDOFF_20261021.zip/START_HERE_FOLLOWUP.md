# Current handoff - 21 October 2026

Decision CONDITIONAL_HOLD. Start with [the new handoff](research_completion/phase3/followup_20261021/HANDOFF.md).

This consolidated ZIP contains safe previous scientific artifacts, the current follow-up and presentation files, and the immutable original Phase 3 ZIP in research_completion/phase3/deliverables/. Validate this consolidated archive using root SHA256SUMS.txt. Historical manifests under phase3/deliverables/ describe the older embedded ZIP, not the updated overlay. No private cases, outcome rows, key or reading-copy papers are included. Your LOCAL_ONLY reviewer pack is a separate local Downloads delivery.
