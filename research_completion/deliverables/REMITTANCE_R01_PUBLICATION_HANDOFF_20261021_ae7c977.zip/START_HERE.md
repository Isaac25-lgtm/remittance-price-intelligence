# R01 publication-completion handoff

**CONDITIONAL_MORE_EVIDENCE - NOT YET PUBLICATION-READY.** Operational model: none. Investigator: Isaac Omoding. This is a conditional retrospective research dossier, not a journal submission or endorsed consumer service.

- [Scientific verdict](research_completion/assessment/PUBLICATION_VERDICT.md)
- [Complete conditional evidence report](research_completion/manuscript/conditional_research_report.md)
- [Execution evidence](research_completion/assessment/final_execution_report.md)
- [Remaining blockers](research_completion/assessment/REMAINING_BLOCKERS.md)
- [Source/availability audit](research_completion/data/historical_publication_timing.md)
- [Closest-work matrix](research_completion/literature/closest_work_matrix.md)
- [Models](research_completion/models/model_comparison.csv)
- [Paired uncertainty](research_completion/models/paired_dependence.csv)
- [Reproduction instructions](README.md)
- [Git/download state](research_completion/deliverables/git_and_download_links.md)

Reproduce locally with Python3.12 and research_completion/reproducibility/environment_lock.txt; set OMP/BLAS/MKL/NUMEXPR threads to2. Acquire/check the official workbook privately, then run completion_data.py,completion_pipeline.py,completion_report.py,completion_figures.py and the final audit/packager. Original results are immutable; exact cross-platform numeric reproduction is not asserted. The live aggregate-only research dashboard is https://isaac-remittance-research.streamlit.app/; redeployment must be verified separately.

The World Bank, Remittance Prices Worldwide, available at http://remittanceprices.worldbank.org (CC BY 4.0). No endorsement. No raw data, provider quote records, predictions, fitted binaries, secrets or copyrighted source PDFs are included.
